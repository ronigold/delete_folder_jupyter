import shutil
def delete_folder(folder_name):
    shutil.rmtree(folder_name)